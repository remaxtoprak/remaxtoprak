# RE/MAX Toprak Web Sitesi: Kurulum Rehberi

Bu klasör sitenin tamamını içerir. Site, RE/MAX Türkiye'deki ofis sayfanızdaki
(https://remax.com.tr/tr/ofis/detay/toprak) ilanları ve ekibi **otomatik olarak** gösterir.
RE/MAX Türkiye'ye yeni bir ilan girildiğinde, fiyat değiştiğinde ya da ilan kaldırıldığında
siteniz en geç **15 dakika** içinde kendini günceller. Elle bir şey yapmanız gerekmez.

## Klasör yapısı

| Dosya / klasör | Ne işe yarar |
|---|---|
| `index.html` | Sitenin kendisi (ana sayfa, ilanlar, danışmanlar, danışman profili, iletişim) |
| `css/site.css` | Tasarım (RE/MAX 2026 kurumsal renkleri, Montserrat yazı tipi, eğik "slash" deseni) |
| `js/app.js` | İlan filtreleme, danışman sayfaları, ilan detay penceresi, kredi hesaplayıcı |
| `js/config.js` | Ayarlar (API adresi, sayfa başına ilan sayısı vb.) |
| `netlify/functions/ilanlar.mjs` | **Canlı senkron:** RE/MAX Türkiye'den ilanları çeken sunucu fonksiyonu (`/api/ilanlar`) |
| `data/listings.json` | Yedek veri (20 Kasım 2026 itibarıyla 320 ilan, 47 kişilik ekip). Canlı bağlantı koparsa site bunu gösterir |
| `img/p/`, `img/a/` | İlan ve danışman fotoğraflarının küçük yedek kopyaları |
| `img/logo-*.svg`, `img/hero.jpg` | Kurumsal kimlik klasörünüzden alınan RE/MAX Toprak ofis logosu ve ana görsel |

## Nasıl çalışır?

1. Ziyaretçi siteyi açar.
2. Site `/api/ilanlar` adresine sorar.
3. Bu fonksiyon RE/MAX Türkiye'deki ofis sayfanızın 16 sayfasını, ekip sayfasını ve yorumlarınızı okur (yaklaşık 4 saniye).
4. Sonuç 15 dakika önbellekte tutulur, sonraki ziyaretçiler anında görür.
5. Fotoğraflar doğrudan RE/MAX Türkiye'nin fotoğraf sunucusundan (i.remax.com.tr) yüklenir.

Kategoriler RE/MAX Türkiye ile birebir aynıdır:
- **İşlem tipi:** Satılık / Kiralık / Devren Satılık / Devren Kiralık
- **Emlak tipi:** Konut / Ticari / Arsa-Arazi
- **Alt kategoriler:** Daire, Villa, Dükkan & Mağaza, Tarla… (otomatik)

Her ilan doğru danışmanla eşleşir. Danışman sayfasında o danışmanın satılık ve kiralık bütün portföyü listelenir.

## Yayınlama: Netlify (önerilen, ücretsiz)

> Önemli: Netlify'ın "sürükle-bırak" (Netlify Drop) yöntemi sunucu fonksiyonlarını **çalıştırmaz**.
> Canlı senkron için aşağıdaki iki yoldan birini kullanın.

**Yol A: GitHub ile (en kolay bakım)**
1. github.com'da ücretsiz bir hesap açın, yeni bir depo (repository) oluşturun, bu klasördeki tüm dosyaları yükleyin.
2. app.netlify.com'a GitHub hesabınızla girin. **Add new site → Import an existing project** ile bu depoyu seçin.
3. Build ayarlarını boş bırakın (netlify.toml dosyası her şeyi ayarlar). **Deploy** deyin.
4. Birkaç dakika sonra `https://<isim>.netlify.app/api/ilanlar` adresini açın. Uzun bir JSON görüyorsanız canlı senkron çalışıyor demektir.

**Yol B: Netlify CLI ile (bilgisayardan tek komut)**
```bash
npm install -g netlify-cli
cd bu-klasor
netlify login
netlify deploy --prod
```

**Alan adını (domain) bağlama:** Netlify'da **Site configuration → Domain management → Add a domain** bölümüne alan adınızı yazın. Ardından alan adını aldığınız firmanın panelinde Netlify'ın gösterdiği DNS kayıtlarını girin. SSL (https) otomatik kurulur.

Kurumsal kılavuzun "Domain Names" bölümüne göre "remax" içeren alan adı *remax + ofis adı + konum* şeklinde olmalıdır (ör. `remaxtoprakbeylikduzu.com`). `remax.com.tr` dışında yurt dışı bölge kuralları için RE/MAX Türkiye'ye danışın.

## Wix'te yayınlamak isterseniz

Wix, hazır HTML siteleri olduğu gibi içe aktarmaz. İki seçenek var:

1. **Tasarımı Wix'te yeniden kurmak.** Renkler, yazı tipi ve bölümler bu tasarımla aynı yapılır. İlanlar için Wix'in kod özelliği (Velo) açılır, `ilanlar.mjs` içindeki `fetchAll()` mantığı bir Wix backend fonksiyonuna taşınır ve Wix CMS (veri tablosu) bir zamanlanmış görevle (jobs.config) her 15 dakikada güncellenir. Daha fazla emek ister.
2. **Siteyi Netlify'da yayınlayıp alan adını oraya yönlendirmek.** En hızlı ve tam otomatik yol budur. Wix'te mevcut siteniz varsa bir alt alan adı (ör. `ilanlar.alanadiniz.com`) da kullanılabilir.

## Dikkat edilmesi gerekenler

- **Resmi API (önerilir):** remax.com.tr sitesinin altında **"API Erişim Talebi"** formu bulunuyor. Formda RE/MAX Türkiye, yayındaki ilanlarınızı resmi bir API ile paylaştığını belirtiyor. Ofis adına bu formu doldurmanızı öneririm. Resmi API erişimi gelirse sadece `netlify/functions/ilanlar.mjs` içindeki `fetchAll()` fonksiyonu değiştirilir, sitenin geri kalanı aynı kalır.
- **Şu anki yöntem:** Fonksiyon, RE/MAX Türkiye'nin herkese açık ofis sayfasını okur. RE/MAX Türkiye sayfa yapısını değiştirirse veya sunucudan gelen istekleri engellerse fonksiyon hata verir. Site bu durumda otomatik olarak `data/listings.json` yedeğini gösterir (sayfada "Son güncelleme" etiketi çıkar). Kurulumdan sonra `/api/ilanlar` adresini mutlaka bir kez test edin.
- **Formlar:** Değerleme formu şu an sadece "talebiniz alındı" mesajı gösterir. E-postanıza gelmesi için Netlify'da yayınladıktan sonra `<form>` etiketine `data-netlify="true"` eklemek yeterlidir. İsterseniz bunu ben yaparım.
- **Danışman telefonları:** RE/MAX Türkiye ekip sayfası danışmanların cep telefonlarını paylaşmıyor. Bu yüzden danışman sayfalarındaki "Ara" butonu ofis numarasına (+90 212 879 28 28) gider. Danışman telefonlarını ya da WhatsApp numaralarını gönderirseniz eklenebilir.
- **Satılmış/kiralanmış geçmiş:** RE/MAX Türkiye yalnızca yayındaki ilanları gösteriyor. "Satıldı/Kiralandı" geçmişi herkese açık olmadığı için danışman sayfalarında aktif portföy gösteriliyor.
