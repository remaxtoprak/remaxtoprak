(function () {
  'use strict';
  var CFG = window.TOPRAK_CONFIG || {};
  var OPS = { 1: 'Satılık', 2: 'Kiralık', 3: 'Devren Satılık', 4: 'Devren Kiralık' };
  var MAINS = { 1: 'Konut', 2: 'Ticari', 3: 'Arsa / Arazi' };
  var tl = new Intl.NumberFormat('tr-TR', { maximumFractionDigits: 0 });
  var $ = function (id) { return document.getElementById(id); };
  var esc = function (s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]; }); };

  var D = null;            // ham veri
  var L = [];              // ilan nesneleri
  var TEAM = [];           // ekip nesneleri
  var TEAM_BY_ID = {};
  var LIVE = false;

  // ---------------- Yardımcılar ----------------
  var KEEP_UPPER = /^(M²|M2|AVM|TEM|E-5|E5|İSKİ|TOKİ|TIR|WC|GES|VIP|SPA|KDV|AB|ADA|1\+1|2\+1|3\+1|4\+1|5\+1|5\+2|6\+1)$/;
  function niceTitle(t) {
    t = String(t || '').replace(/\s+/g, ' ').trim();
    var letters = t.replace(/[^A-Za-zÇĞİÖŞÜçğıöşü]/g, '');
    var upper = letters.replace(/[^A-ZÇĞİÖŞÜ]/g, '').length;
    if (letters.length < 6 || upper / letters.length < 0.7) return t;
    // Başlıkta hiç "İ" yoksa yazar büyük "I" harfini "İ" yerine kullanmıştır (Hürrıyet hatasını önler)
    // "İ" yokken "I" varsa harfin ı mı i mi olduğu belirsizdir: yanlış çevirmemek için orijinal bırakılır
    if (t.indexOf('İ') < 0 && t.indexOf('I') >= 0) return t;
    var lower = function (w) { return w.toLocaleLowerCase('tr-TR'); };
    return t.split(' ').map(function (w) {
      if (KEEP_UPPER.test(w) || /\d/.test(w)) return w.toLocaleUpperCase('tr-TR');
      var lw = lower(w);
      var i = lw.search(/[a-zçğıöşü]/);
      if (i < 0) return lw;
      return lw.slice(0, i) + lw.charAt(i).toLocaleUpperCase('tr-TR') + lw.slice(i + 1);
    }).join(' ');
  }
  function parseNum(s) { return +(String(s || '').replace(/\./g, '').replace(',', '.')) || 0; }
  function splitLoc(loc) {
    var p = String(loc || '').split('/').map(function (x) { return x.trim(); }).filter(Boolean);
    var neigh = p.length ? p[p.length - 1] : '';
    var town = p.length > 1 ? p[p.length - 2] : '';
    var city = p.length > 2 ? p[0] : 'İstanbul';
    return { town: town, neigh: neigh, city: city, label: town + (neigh ? ' / ' + neigh : '') + (city !== 'İstanbul' ? ' (' + city + ')' : '') };
  }
  function priceLabel(l) {
    var s = tl.format(l.price) + ' ₺';
    return (l.op === 2 || l.op === 4) ? s + ' <small>/ ay</small>' : s;
  }
  function roomsNum(r) { var m = /^(\d+)/.exec(r || ''); return m ? +m[1] : 0; }

  // Fotoğraf kaynakları: önizlemede yerel kopya, canlıda RE/MAX sunucusu (karşılıklı yedekli)
  var PHOTOS = {};
  function localSrc(key, path) { return PHOTOS[key] ? 'data:image/webp;base64,' + PHOTOS[key] : path; }
  function listingImg(l) {
    var remote = l.img ? CFG.photoBase + l.img : '';
    var local = localSrc('p' + l.code, 'img/p/' + l.code + '.webp');
    if (!LIVE && CFG.localPhotos) return { src: local, alt: remote };
    return { src: remote || local, alt: local };
  }
  function agentImg(a) {
    var remote = a.photo ? CFG.photoBase + a.photo : '';
    var local = localSrc('a' + a.id, 'img/a/' + a.id + '.webp');
    if (!LIVE && CFG.localPhotos) return { src: local, alt: remote };
    return { src: remote || local, alt: local };
  }
  function imgTag(o, alt, extra) {
    return '<img src="' + esc(o.src) + '" data-alt="' + esc(o.alt) + '" alt="' + esc(alt) + '" loading="lazy" ' + (extra || '') + '>';
  }
  document.addEventListener('error', function (e) {
    var t = e.target;
    if (t && t.tagName === 'IMG' && t.dataset.alt && !t.dataset.tried) {
      t.dataset.tried = '1';
      t.src = t.dataset.alt;
    } else if (t && t.tagName === 'IMG' && t.dataset.tried === '1') {
      t.dataset.tried = '2';
      t.style.visibility = 'hidden';
    }
  }, true);

  // ---------------- Veri yükleme ----------------
  function normalize(d) {
    var F = d.fields, idx = {};
    F.forEach(function (f, i) { idx[f] = i; });
    L = d.rows.map(function (r, order) {
      var o = {};
      F.forEach(function (f) { o[f] = r[idx[f]]; });
      o.order = order;
      o.catName = (d.cats[o.cat] || '').trim();
      o.title = niceTitle(o.title);
      o.m2n = parseNum(o.m2);
      o.loc2 = splitLoc(o.loc);
      o.search = (o.title + ' ' + o.loc + ' ' + o.code + ' ' + o.catName).toLocaleLowerCase('tr-TR');
      return o;
    });
    var TF = d.teamFields, tidx = {};
    TF.forEach(function (f, i) { tidx[f] = i; });
    TEAM = d.team.map(function (r) {
      var o = {};
      TF.forEach(function (f) { o[f] = r[tidx[f]]; });
      o.name = String(o.name).trim();
      o.listings = L.filter(function (l) { return l.emp === o.id; });
      o.kind = /Broker/i.test(o.title) ? 'broker' : (/Danışmanı/i.test(o.title) ? 'agent' : 'staff');
      o.shortTitle = o.title.replace(/\s*\((MAX|RAPP) Sistem\)/, '');
      return o;
    });
    TEAM_BY_ID = {};
    TEAM.forEach(function (a) { TEAM_BY_ID[a.id] = a; });
  }

  function load() {
    var tryApi = CFG.apiUrl && /^https?:/.test(location.protocol) ? fetchWithTimeout(CFG.apiUrl, 6000) : Promise.reject();
    return tryApi.then(function (d) {
      if (!d || !d.rows || !d.rows.length) throw new Error('boş');
      LIVE = true; return d;
    }).catch(function () {
      return fetch(CFG.snapshotUrl, { cache: 'no-cache' }).then(function (r) { return r.json(); });
    }).then(function (d) {
      D = d; normalize(d);
      // Önizleme: fotoğraf kopyaları tek paket halinde (canlı sitede RE/MAX sunucusu kullanılır)
      if (LIVE || !CFG.localPhotos || !CFG.photoPack) return;
      return fetch(CFG.photoPack).then(function (r) { return r.ok ? r.json() : {}; }).then(function (p) { PHOTOS = p || {}; }).catch(function () {});
    });
  }
  function fetchWithTimeout(url, ms) {
    return new Promise(function (res, rej) {
      var t = setTimeout(function () { rej(new Error('zaman aşımı')); }, ms);
      fetch(url).then(function (r) { if (!r.ok) throw new Error(r.status); return r.json(); })
        .then(function (j) { clearTimeout(t); res(j); }, function (e) { clearTimeout(t); rej(e); });
    });
  }

  function liveBadge(id) {
    var el = $(id); if (!el) return;
    var dt = new Date(D.updated);
    var when = isNaN(dt) ? '' : dt.toLocaleString('tr-TR', { day: '2-digit', month: 'long', hour: '2-digit', minute: '2-digit' });
    el.classList.toggle('snap', !LIVE);
    el.querySelector('span').textContent = (LIVE ? 'Canlı · RE/MAX Türkiye ile senkron · ' : 'Son güncelleme: ') + when;
  }

  // ---------------- Kart şablonları ----------------
  function cardHTML(l) {
    var a = TEAM_BY_ID[l.emp];
    var opCls = l.op === 1 ? 'sale' : (l.op === 2 ? 'rent' : 'dev');
    var specs = [];
    if (l.rooms) specs.push('<span><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M3 18V7M3 13h18v5M21 13a3 3 0 0 0-3-3h-7v3"/></svg>' + esc(l.rooms) + '</span>');
    if (l.m2) specs.push('<span>' + esc(l.m2) + ' m²</span>');
    if (l.floor) specs.push('<span><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M4 20h16M6 20V9l6-5 6 5v11"/></svg>' + esc(/^\d+$/.test(l.floor) ? l.floor + '. kat' : l.floor) + '</span>');
    return '<button type="button" class="card" data-code="' + esc(l.code) + '" aria-label="' + esc(l.title) + ' ilan detayını aç">' +
      '<div class="card-media">' + imgTag(listingImg(l), l.title + ' – ' + l.loc2.label) +
      '<span class="badge ' + opCls + '">' + OPS[l.op] + '</span>' +
      (l.disc ? '<span class="badge disc">İndirimli</span>' : '') +
      (l.nimg > 1 ? '<span class="photos"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2" aria-hidden="true"><rect x="3" y="6" width="18" height="14" rx="2"/><circle cx="12" cy="13" r="3.5"/><path d="M8 6l1.5-2h5L16 6"/></svg>' + l.nimg + '</span>' : '') +
      '</div><div class="card-body">' +
      '<div class="cat">' + esc(MAINS[l.main] || '') + ' · ' + esc(l.catName) + '</div>' +
      '<div class="price">' + priceLabel(l) + '</div>' +
      '<div class="card-title">' + esc(l.title) + '</div>' +
      '<div class="loc"><svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M12 21s-7-6.2-7-11a7 7 0 0 1 14 0c0 4.8-7 11-7 11z"/><circle cx="12" cy="10" r="2.5"/></svg>' + esc(l.loc2.label) + '</div>' +
      (a ? '<div class="agent-chip">' + imgTag(agentImg(a), a.name) + esc(a.name) + '</div>' : '') +
      '<div class="specs">' + specs.join('') + '</div>' +
      '</div></button>';
  }
  function agentHTML(a) {
    var sale = a.listings.filter(function (l) { return l.op === 1 || l.op === 3; }).length;
    var rent = a.listings.length - sale;
    return '<button type="button" class="agent" data-agent="' + esc(a.slug) + '" aria-label="' + esc(a.name) + ' profilini aç">' +
      '<div class="photo">' + imgTag(agentImg(a), a.name + ', RE/MAX Toprak Beylikdüzü emlak danışmanı') +
      (a.listings.length ? '<span class="pill">' + a.listings.length + ' ilan</span>' : '') + '</div>' +
      '<h3>' + esc(a.name) + '</h3><div class="role">' + esc(a.shortTitle) + '</div>' +
      '<div class="meta">' + (a.reviews ? '<span><span class="star">★</span> ' + String(a.rating).replace('.', ',') + ' (' + a.reviews + ' yorum)</span>' : '') +
      (a.listings.length ? '<span>' + sale + ' satılık · ' + rent + ' kiralık</span>' : '') + '</div></button>';
  }

  // ---------------- Ana sayfa ----------------
  function renderHome() {
    var agents = TEAM.filter(function (a) { return a.kind === 'agent'; });
    $('stats').innerHTML =
      '<div class="stat"><b>' + L.length + '</b><span>Aktif ilan</span></div>' +
      '<div class="stat"><b>' + agents.length + '</b><span>Gayrimenkul danışmanı</span></div>' +
      '<div class="stat"><b>' + D.office.reviewsTotal + '</b><span>Müşteri yorumu</span></div>' +
      '<div class="stat"><b><em>★</em> ' + String(D.office.reviewsAvg.toFixed ? D.office.reviewsAvg.toFixed(1) : D.office.reviewsAvg).replace('.', ',') + '</b><span>Ortalama puan</span></div>';
    $('latestGrid').innerHTML = L.slice(0, 6).map(cardHTML).join('');

    var tiles = [1, 2, 3].map(function (m) {
      var items = L.filter(function (l) { return l.main === m; });
      var cover = items.filter(function (l) { return l.nimg > 3; })[0] || items[0];
      var sale = items.filter(function (l) { return l.op === 1 || l.op === 3; }).length;
      return '<a class="cat-tile" href="#ilanlar" data-main="' + m + '">' + (cover ? imgTag(listingImg(cover), 'Beylikdüzü ' + MAINS[m].toLowerCase() + ' ilanları') : '') +
        '<div><h3>' + MAINS[m] + '</h3><p style="opacity:.85;font-size:14px;margin-top:4px">' + sale + ' satılık · ' + (items.length - sale) + ' kiralık</p><span class="count">' + items.length + ' ilan</span></div></a>';
    });
    $('catTiles').innerHTML = tiles.join('');

    var top = agents.slice().sort(function (a, b) { return b.listings.length - a.listings.length; }).slice(0, 8);
    $('teamPreview').innerHTML = top.map(agentHTML).join('');

    $('revTotal').textContent = D.office.reviewsTotal + ' doğrulanmış yorum';
    $('reviewGrid').innerHTML = (D.reviews || []).map(function (r) {
      return '<article class="review"><div class="stars" aria-label="' + r[1] + ' yıldız">' + '★★★★★'.slice(0, r[1]) + '</div><p>' + esc(r[3]) + '</p><footer><span>' + esc(r[0]) + '</span><span>' + esc(r[2].replace(/-/g, '.')) + '</span></footer></article>';
    }).join('');
    liveBadge('liveBadge');
  }

  // ---------------- İlan tarayıcı ----------------
  var F = { q: '', op: 0, main: 0, cat: '', town: '', room: '', min: '', max: '', agent: '', sort: 'new' };
  var shown = CFG.pageSize || 24;

  function segButtons(el, items, key) {
    el.innerHTML = items.map(function (it) {
      return '<button type="button" aria-pressed="' + (F[key] === it[0]) + '" data-v="' + it[0] + '">' + it[1] + (it[2] != null ? '<span class="n">' + it[2] + '</span>' : '') + '</button>';
    }).join('');
  }
  function base(skip) {
    return L.filter(function (l) {
      if (skip !== 'op' && F.op && l.op !== F.op) return false;
      if (skip !== 'main' && F.main && l.main !== F.main) return false;
      return true;
    });
  }
  function buildFilters() {
    var forOp = base('op'), forMain = base('main');
    var opCount = function (v) { return forOp.filter(function (l) { return l.op === v; }).length; };
    var ops = [[0, 'Tümü', forOp.length]];
    [1, 2, 3, 4].forEach(function (v) { var n = opCount(v); if (n) ops.push([v, OPS[v], n]); });
    segButtons($('fOp'), ops, 'op');
    var mains = [[0, 'Tümü', forMain.length]];
    [1, 2, 3].forEach(function (v) { mains.push([v, MAINS[v], forMain.filter(function (l) { return l.main === v; }).length]); });
    segButtons($('fMain'), mains, 'main');

    var b = base();
    var cats = {}; b.forEach(function (l) { cats[l.catName] = (cats[l.catName] || 0) + 1; });
    $('fCat').innerHTML = '<option value="">Tümü</option>' + Object.keys(cats).sort(function (x, y) { return x.localeCompare(y, 'tr'); })
      .map(function (c) { return '<option value="' + esc(c) + '"' + (F.cat === c ? ' selected' : '') + '>' + esc(c) + ' (' + cats[c] + ')</option>'; }).join('');
    if (F.cat && !cats[F.cat]) F.cat = '';
    var towns = {}; b.forEach(function (l) { var t = l.loc2.town; if (t) towns[t] = (towns[t] || 0) + 1; });
    $('fTown').innerHTML = '<option value="">Tümü</option>' + Object.keys(towns).sort(function (x, y) { return towns[y] - towns[x]; })
      .map(function (t) { return '<option value="' + esc(t) + '"' + (F.town === t ? ' selected' : '') + '>' + esc(t) + ' (' + towns[t] + ')</option>'; }).join('');
    var ag = TEAM.filter(function (a) { return a.listings.length; }).sort(function (x, y) { return x.name.localeCompare(y.name, 'tr'); });
    $('fAgent').innerHTML = '<option value="">Tüm danışmanlar</option>' + ag.map(function (a) { return '<option value="' + a.id + '"' + (String(F.agent) === String(a.id) ? ' selected' : '') + '>' + esc(a.name) + ' (' + a.listings.length + ')</option>'; }).join('');
    $('fRoom').value = F.room; $('fQ').value = F.q; $('fMin').value = F.min; $('fMax').value = F.max; $('fSort').value = F.sort;
  }
  function filtered() {
    var q = F.q.toLocaleLowerCase('tr-TR').trim();
    var out = base().filter(function (l) {
      if (F.cat && l.catName !== F.cat) return false;
      if (F.town && l.loc2.town !== F.town) return false;
      if (F.agent && String(l.emp) !== String(F.agent)) return false;
      if (F.room) { if (F.room === '5+') { if (roomsNum(l.rooms) < 5) return false; } else if (l.rooms !== F.room) return false; }
      if (F.min && l.price < +F.min) return false;
      if (F.max && l.price > +F.max) return false;
      if (q && q.split(/\s+/).some(function (w) { return l.search.indexOf(w) < 0; })) return false;
      return true;
    });
    var s = F.sort;
    out.sort(function (a, b) {
      if (s === 'pa') return a.price - b.price;
      if (s === 'pd') return b.price - a.price;
      if (s === 'ma') return a.m2n - b.m2n;
      if (s === 'md') return b.m2n - a.m2n;
      return a.order - b.order;
    });
    return out;
  }
  function renderList(resetPaging) {
    if (resetPaging) shown = CFG.pageSize || 24;
    buildFilters();
    var res = filtered();
    $('resultCount').textContent = res.length + ' ilan bulundu';
    $('listGrid').innerHTML = res.slice(0, shown).map(cardHTML).join('');
    $('listEmpty').style.display = res.length ? 'none' : 'block';
    $('moreBtn').hidden = res.length <= shown;
    liveBadge('liveBadge2');
  }
  function setFilter(patch) {
    Object.keys(F).forEach(function (k) { if (k !== 'sort') F[k] = (k === 'op' || k === 'main') ? 0 : ''; });
    Object.keys(patch || {}).forEach(function (k) { F[k] = patch[k]; });
  }

  // ---------------- Ekip ----------------
  function renderTeam() {
    var groups = [
      ['Yönetim', TEAM.filter(function (a) { return a.kind === 'broker'; })],
      ['Gayrimenkul danışmanları', TEAM.filter(function (a) { return a.kind === 'agent'; }).sort(function (a, b) { return b.listings.length - a.listings.length || a.name.localeCompare(b.name, 'tr'); })]
    ];
    var staff = TEAM.filter(function (a) { return a.kind === 'staff'; });
    var html = groups.map(function (g) {
      return '<div class="team-group"><h3>' + g[0] + ' <span>' + g[1].length + ' kişi</span></h3><div class="agent-grid">' + g[1].map(agentHTML).join('') + '</div></div>';
    }).join('');
    html += '<div class="team-group"><h3>Ofis ekibi <span>' + staff.length + ' kişi</span></h3><div class="staff-grid">' + staff.map(function (a) {
      return '<div class="staff">' + imgTag(agentImg(a), a.name + ', RE/MAX Toprak Beylikdüzü ofis ekibi') + '<b>' + esc(a.name) + '</b><span>' + esc(a.shortTitle) + '</span></div>';
    }).join('') + '</div></div>';
    $('teamAll').innerHTML = html;
  }

  var pFilter = 'all';
  function renderProfile(slug) {
    var a = TEAM.filter(function (x) { return x.slug === slug; })[0];
    if (!a) { location.hash = 'danismanlar'; return; }
    var sale = a.listings.filter(function (l) { return l.op === 1 || l.op === 3; });
    var rent = a.listings.filter(function (l) { return l.op === 2 || l.op === 4; });
    $('pCrumb').textContent = a.name;
    setMeta(a.name + ' | Beylikdüzü Emlak Danışmanı | RE/MAX Toprak', 'Beylikdüzü emlak danışmanı ' + a.name + ' (RE/MAX Toprak): ' + a.listings.length + ' aktif satılık ve kiralık ilan, iletişim bilgileri ve müşteri yorumları.');
    $('profileCard').innerHTML =
      '<div class="ph">' + imgTag(agentImg(a), a.name + ', RE/MAX Toprak Beylikdüzü emlak danışmanı') + '</div><div class="body">' +
      '<div><h2>' + esc(a.name) + '</h2><div class="role">' + esc(a.shortTitle) + ' · RE/MAX Toprak</div></div>' +
      '<div class="kv"><div><b>' + a.listings.length + '</b><span>Aktif ilan</span></div><div><b>' + (a.reviews ? '★ ' + String(a.rating).replace('.', ',') : '–') + '</b><span>' + (a.reviews ? a.reviews + ' yorum' : 'Puan') + '</span></div>' +
      '<div><b>' + sale.length + '</b><span>Satılık</span></div><div><b>' + rent.length + '</b><span>Kiralık</span></div></div>' +
      '<a class="btn btn-red" href="tel:+902128792828">Ofisi ara</a>' +
      '<a class="btn btn-outline" href="mailto:info@remaxtoprak.com?subject=' + encodeURIComponent(a.name + ' ile görüşmek istiyorum') + '">E-posta gönder</a>' +
      '<div class="office-line">' + (a.since ? a.since + ' yılından beri RE/MAX ailesinde. ' : '') + 'RE/MAX Toprak · Beylikdüzü / İstanbul</div></div>';
    var tabs = [['all', 'Tümü', a.listings.length], ['sale', 'Satılık', sale.length], ['rent', 'Kiralık', rent.length]];
    $('pTabs').innerHTML = tabs.map(function (t) { return '<button class="chip" type="button" aria-pressed="' + (pFilter === t[0]) + '" data-p="' + t[0] + '">' + t[1] + ' (' + t[2] + ')</button>'; }).join('');
    var list = pFilter === 'sale' ? sale : (pFilter === 'rent' ? rent : a.listings);
    $('pTitle').textContent = a.name.split(' ')[0] + "'in portföyü";
    $('pGrid').innerHTML = list.map(cardHTML).join('');
    $('pEmpty').style.display = list.length ? 'none' : 'block';
    $('pTabs').onclick = function (e) { var b = e.target.closest('[data-p]'); if (!b) return; pFilter = b.dataset.p; renderProfile(slug); };
  }

  // ---------------- İlan detayı ----------------
  function openDetail(code) {
    var l = L.filter(function (x) { return x.code === code; })[0];
    if (!l) return;
    var a = TEAM_BY_ID[l.emp];
    var facts = [['İlan no', l.code], ['İşlem', OPS[l.op]], ['Kategori', MAINS[l.main] + ' · ' + l.catName], ['Alan', l.m2 ? l.m2 + ' m²' : '–']];
    if (l.rooms) facts.push(['Oda', l.rooms]);
    if (l.floor) facts.push(['Kat', /^\d+$/.test(l.floor) ? l.floor + '. kat' : l.floor]);
    if (l.m2n && (l.op === 1 || l.op === 3)) facts.push(['m² fiyatı', tl.format(Math.round(l.price / l.m2n)) + ' ₺']);
    var remaxUrl = 'https://remax.com.tr/tr/portfoy/' + encodeURIComponent(l.code);
    $('modalBody').innerHTML =
      '<div class="detail"><div class="media">' + imgTag(listingImg(l), l.title + ' – ' + l.loc2.label) + '<span class="badge ' + (l.op === 1 ? 'sale' : l.op === 2 ? 'rent' : 'dev') + '">' + OPS[l.op] + '</span></div>' +
      '<div class="info"><div class="code">İLAN NO ' + esc(l.code) + '</div><h2 id="dTitle">' + esc(l.title) + '</h2>' +
      '<div class="loc">' + esc(l.loc2.label) + '</div><div class="price">' + priceLabel(l) + '</div>' +
      '<div class="facts">' + facts.map(function (f) { return '<div><span>' + f[0] + '</span><b>' + esc(f[1]) + '</b></div>'; }).join('') + '</div>' +
      (a ? '<button type="button" class="agent-row" data-agent="' + esc(a.slug) + '">' + imgTag(agentImg(a), a.name) + '<div><b>' + esc(a.name) + '</b><span>' + esc(a.shortTitle) + ' · tüm ilanlarını gör →</span></div></button>' : '') +
      '<div class="actions"><a class="btn btn-red" href="tel:+902128792828">Hemen ara</a><a class="btn btn-outline" href="' + remaxUrl + '" target="_blank" rel="noopener">' + (l.nimg > 1 ? l.nimg + ' fotoğrafı gör' : 'Tüm detaylar') + '</a></div>' +
      '<p class="note">Fotoğraf galerisi, açıklama ve video RE/MAX Türkiye ilan sayfasında yer alır.</p>' +
      '</div></div>';
    $('modal').classList.add('open');
    document.body.style.overflow = 'hidden';
    $('modalClose').focus();
  }
  function closeDetail() { $('modal').classList.remove('open'); document.body.style.overflow = ''; }

  function setMeta(t, d) {
    document.title = t;
    var m = document.querySelector('meta[name="description"]'); if (m) m.setAttribute('content', d);
  }
  var META = {
    home: ["Beylikdüzü Emlak: Satılık ve Kiralık Daire | RE/MAX Toprak", "Beylikdüzü emlak ofisi RE/MAX Toprak: Beylikdüzü'nde satılık ve kiralık daire, villa, dükkan ve arsa ilanları, uzman danışmanlar ve ücretsiz değerleme."],
    ilanlar: ["Beylikdüzü Satılık ve Kiralık İlanlar | RE/MAX Toprak", "Beylikdüzü satılık daire, kiralık daire, dükkan ve arsa ilanları: RE/MAX Toprak portföyü RE/MAX Türkiye ile canlı senkron ve her gün güncel."],
    danismanlar: ["Beylikdüzü Emlak Danışmanları | RE/MAX Toprak", "Beylikdüzü emlak danışmanları: RE/MAX Toprak ekibini tanıyın, danışmanların satılık ve kiralık portföylerini inceleyin, size uygun uzmanla görüşün."],
    sss: ["Beylikdüzü Emlak SSS: Sıkça Sorulan Sorular | RE/MAX Toprak", "Beylikdüzü'nde ev almak, kiralamak ve yaşamak üzerine merak edilenler: mahalleler, ulaşım, tapu harcı, komisyon, kira artışı ve daha fazlası."]
  };
  // ---------------- Yönlendirme (hash) ----------------
  var HOME_ANCHORS = ['degerleme', 'kredi', 'iletisim'];
  var currentKey = null;
  var pushed = false;
  function route() {
    var h = (location.hash || '').replace(/^#/, '');
    var view = 'home', slug = null;
    if (h === 'ilanlar') view = 'ilanlar';
    else if (h === 'danismanlar') view = 'danismanlar';
    else if (h === 'sss') view = 'sss';
    else if (h.indexOf('danisman-') === 0) { view = 'danisman'; slug = h.slice(9); }
    else if (h.indexOf('ilan-') === 0) {
      if (!document.querySelector('.view.active')) { $('view-home').classList.add('active'); currentKey = ''; }
      openDetail(h.slice(5)); return;
    }
    var key = view + ':' + (slug || '');
    var wasModal = $('modal').classList.contains('open');
    closeDetail();
    if (wasModal && key === currentKey && HOME_ANCHORS.indexOf(h) < 0) return; // pencere kapandı, sayfa yerinde kalsın
    currentKey = key;
    ['home', 'ilanlar', 'danismanlar', 'danisman', 'sss'].forEach(function (v) { $('view-' + v).classList.toggle('active', v === view); });
    if (META[view]) setMeta(META[view][0], META[view][1]);
    if (view === 'ilanlar') renderList(true);
    if (view === 'danismanlar') renderTeam();
    if (view === 'danisman') { pFilter = 'all'; renderProfile(slug); }
    if (HOME_ANCHORS.indexOf(h) >= 0) { var t = $(h); if (t) t.scrollIntoView({ behavior: 'smooth' }); }
    else window.scrollTo(0, 0);
  }

  // ---------------- Olaylar ----------------
  function bind() {
    document.addEventListener('click', function (e) {
      var card = e.target.closest('[data-code]');
      if (card) { e.preventDefault(); pushed = true; history.pushState(null, '', '#ilan-' + card.dataset.code); openDetail(card.dataset.code); return; }
      var ag = e.target.closest('[data-agent]');
      if (ag) { e.preventDefault(); closeDetail(); location.hash = 'danisman-' + ag.dataset.agent; return; }
      var link = e.target.closest('a[data-op],a[data-main]');
      if (link) {
        setFilter({ op: +link.dataset.op || 0, main: +link.dataset.main || 0 });
        closeMenu();
        if (location.hash === '#ilanlar') { e.preventDefault(); renderList(true); window.scrollTo(0, 0); }
      }
    });
    function dismiss() { if (pushed) { pushed = false; history.back(); } else { closeDetail(); history.replaceState(null, '', '#anasayfa'); } }
    $('modalClose').addEventListener('click', dismiss);
    $('modal').addEventListener('click', function (e) { if (e.target === $('modal')) dismiss(); });
    document.addEventListener('keydown', function (e) { if (e.key === 'Escape' && $('modal').classList.contains('open')) dismiss(); });
    window.addEventListener('hashchange', route);

    // filtreler
    $('fOp').addEventListener('click', function (e) { var b = e.target.closest('button'); if (!b) return; F.op = +b.dataset.v; renderList(true); });
    $('fMain').addEventListener('click', function (e) { var b = e.target.closest('button'); if (!b) return; F.main = +b.dataset.v; F.cat = ''; renderList(true); });
    [['fCat', 'cat'], ['fTown', 'town'], ['fRoom', 'room'], ['fAgent', 'agent'], ['fSort', 'sort']].forEach(function (p) {
      $(p[0]).addEventListener('change', function () { F[p[1]] = this.value; renderList(true); });
    });
    var deb;
    [['fQ', 'q'], ['fMin', 'min'], ['fMax', 'max']].forEach(function (p) {
      $(p[0]).addEventListener('input', function () { var v = this.value; clearTimeout(deb); deb = setTimeout(function () { F[p[1]] = v; renderList(true); var el = $(p[0]); el.focus(); }, 250); });
    });
    $('fReset').addEventListener('click', function () { setFilter({}); renderList(true); });
    $('moreBtn').addEventListener('click', function () { shown += CFG.pageSize || 24; renderList(false); });
    $('filterToggle').addEventListener('click', function () { var o = $('filters').classList.toggle('open'); this.setAttribute('aria-expanded', o); });

    // ana sayfa arama
    var sop = '1';
    document.querySelectorAll('.search-tabs button').forEach(function (b) {
      b.addEventListener('click', function () {
        document.querySelectorAll('.search-tabs button').forEach(function (x) { x.setAttribute('aria-selected', 'false'); });
        b.setAttribute('aria-selected', 'true'); sop = b.dataset.sop;
        if (sop === 'value') $('degerleme').scrollIntoView({ behavior: 'smooth' });
      });
    });
    $('searchForm').addEventListener('submit', function (e) {
      e.preventDefault();
      if (sop === 'value') { $('degerleme').scrollIntoView({ behavior: 'smooth' }); return; }
      setFilter({ op: +sop, main: +$('sMain').value || 0, room: $('sRoom').value, max: $('sMax').value, q: $('sQ').value });
      if (location.hash === '#ilanlar') renderList(true); else location.hash = 'ilanlar';
    });

    $('valForm').addEventListener('submit', function (e) { e.preventDefault(); $('valMsg').style.display = 'block'; this.reset(); });

    // mobil menü
    var mb = document.querySelector('.menu-btn'), mn = $('mobileNav');
    mb.addEventListener('click', function () { var o = mn.classList.toggle('open'); mb.setAttribute('aria-expanded', o ? 'true' : 'false'); });
    function closeMenu() { mn.classList.remove('open'); mb.setAttribute('aria-expanded', 'false'); }
    window.closeMenu = closeMenu;
    mn.querySelectorAll('a').forEach(function (a) { a.addEventListener('click', closeMenu); });

    // kredi hesaplayıcı
    function calc() {
      var P = +$('cPrice').value, d = +$('cDown').value, r = +$('cRate').value / 100, n = +$('cTerm').value;
      var down = P * d / 100, loan = P - down, m = r > 0 ? loan * r / (1 - Math.pow(1 + r, -n)) : loan / n;
      $('oPrice').textContent = tl.format(P) + ' ₺'; $('oDown').textContent = '%' + d;
      $('oRate').textContent = '%' + (+$('cRate').value).toFixed(2).replace('.', ','); $('oTerm').textContent = n + ' ay';
      $('rMonthly').textContent = tl.format(m) + ' ₺'; $('rLoan').textContent = tl.format(loan) + ' ₺';
      $('rDown').textContent = tl.format(down) + ' ₺'; $('rTotal').textContent = tl.format(m * n) + ' ₺';
    }
    ['cPrice', 'cDown', 'cRate', 'cTerm'].forEach(function (id) { $(id).addEventListener('input', calc); });
    calc();
    $('yr').textContent = new Date().getFullYear();
  }
  function closeMenu() { if (window.closeMenu) window.closeMenu(); }

  bind();
  load().then(function () {
    renderHome();
    route();
  }).catch(function (e) {
    console.error(e);
    $('latestGrid').innerHTML = '<div class="empty" style="display:block">İlanlar şu anda yüklenemedi. Lütfen daha sonra tekrar deneyin.</div>';
    route();
  });
})();
