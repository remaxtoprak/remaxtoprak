/* RE/MAX Toprak site ayarları
 * apiUrl      : Canlı ilan verisini döndüren sunucu fonksiyonu (Netlify'da /api/ilanlar).
 *               Boş bırakılırsa site sadece data/listings.json anlık görüntüsünü kullanır.
 * snapshotUrl : Yedek veri dosyası (API'ye ulaşılamazsa kullanılır).
 * photoBase   : RE/MAX Türkiye fotoğraf sunucusu.
 * localPhotos : true ise önce img/p ve img/a klasöründeki kopyalar denenir (önizleme için).
 */
window.TOPRAK_CONFIG = {
  apiUrl: '/api/ilanlar',
  snapshotUrl: 'data/listings.json',
  photoBase: 'https://i.remax.com.tr/photos/',
  localPhotos: true,
  photoPack: 'data/photos.json',   // sadece önizleme için; canlı sitede kullanılmaz
  pageSize: 24
};
