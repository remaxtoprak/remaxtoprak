// RE/MAX Toprak – canlı ilan senkronu (Netlify Function)
// Adres: /api/ilanlar  (netlify.toml içindeki yönlendirme ile)
//
// RE/MAX Türkiye'deki ofis sayfasını (remax.com.tr/tr/ofis/detay/toprak) okur,
// tüm sayfalardaki ilanları ve ekibi toplayıp sitenin beklediği JSON biçiminde döndürür.
// Sonuç Netlify CDN'inde 15 dakika önbelleğe alınır; böylece RE/MAX'e en fazla 15 dakikada bir istek gider.
//
// NOT: RE/MAX Türkiye resmi API erişimi verirse (remax.com.tr > "API Erişim Talebi"),
// sadece fetchAll() fonksiyonunu resmi API'ye göre değiştirmek yeterli olur; site tarafında değişiklik gerekmez.

const OFFICE_SLUG = 'toprak';
const BASE = 'https://remax.com.tr';
const PHOTO = 'https://i.remax.com.tr/photos/';
const HEADERS = {
  'RSC': '1',
  'Accept': '*/*',
  'Accept-Language': 'tr-TR,tr;q=0.9',
  'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0 Safari/537.36 RemaxToprakSiteSync/1.0'
};

const OFFICE = {
  name: 'RE/MAX Toprak', tagline: 'Güvenilir Yatırımın Doğru Adresi', age: 3,
  phone: '+90 212 879 28 28', phoneHref: '+902128792828', email: 'info@remaxtoprak.com',
  address: 'Barış Mahallesi, Ali Çebi Caddesi, Beytown Apartmanı, No:44/1', district: 'Beylikdüzü / İstanbul',
  lat: 40.99993682018683, lon: 28.65704647958223,
  linkedin: 'https://www.linkedin.com/company/remaxtoprak/',
  remaxUrl: BASE + '/tr/ofis/detay/' + OFFICE_SLUG, reviewsTotal: 675, reviewsAvg: 5
};

// Metin içinden "anahtar": { ... } bloğunu güvenli şekilde çıkarır
function grabAt(t, j) {
  const open = t[j], close = open === '[' ? ']' : '}';
  let d = 0, k = j, inS = false;
  for (; k < t.length; k++) {
    const c = t[k];
    if (inS) { if (c === '\\') { k++; continue; } if (c === '"') inS = false; continue; }
    if (c === '"') inS = true; else if (c === open) d++; else if (c === close) { d--; if (d === 0) break; }
  }
  return JSON.parse(t.slice(j, k + 1));
}
function grab(t, key) {
  const i = t.indexOf('"' + key + '":');
  if (i < 0) return null;
  return grabAt(t, t.indexOf('{', i));
}
async function getText(path) {
  const r = await fetch(BASE + path, { headers: HEADERS });
  if (!r.ok) throw new Error(path + ' -> HTTP ' + r.status);
  return r.text();
}

async function fetchAll() {
  // 1) İlk sayfa: toplam ilan sayısı + ofis yorumları
  const first = await getText(`/tr/ofis/detay/${OFFICE_SLUG}?page=1&tab=portfoylerimiz`);
  const L1 = grab(first, 'officeDetailPropertyListingData');
  if (!L1 || !L1.data) throw new Error('İlan verisi bulunamadı (sayfa yapısı değişmiş olabilir)');
  const total = L1.data.recordCount || L1.data.data.length;
  const perPage = L1.data.data.length || 20;
  const pages = Math.ceil(total / perPage);

  const all = new Map();
  L1.data.data.forEach(x => all.set(x.code, x));
  // 2) Diğer sayfalar (aynı anda en fazla 4 istek)
  const rest = Array.from({ length: Math.max(0, pages - 1) }, (_, i) => i + 2);
  for (let i = 0; i < rest.length; i += 4) {
    const batch = await Promise.all(rest.slice(i, i + 4).map(p =>
      getText(`/tr/ofis/detay/${OFFICE_SLUG}?page=${p}&tab=portfoylerimiz`).then(t => grab(t, 'officeDetailPropertyListingData'))));
    batch.forEach(L => (L?.data?.data || []).forEach(x => all.set(x.code, x)));
  }

  // 3) Ekip
  const teamText = await getText(`/tr/ofis/detay/${OFFICE_SLUG}/ekibimiz`);
  const team = new Map();
  const marker = '{"image":"https://i.remax.com.tr/photos/employee';
  let p = -1;
  while ((p = teamText.indexOf(marker, p + 1)) > 0) {
    try { const o = grabAt(teamText, p); team.set(o.employeeId, o); } catch (e) { /* atla */ }
  }

  // 4) Son yorumlar (ad + soyadın baş harfi)
  const reviews = [];
  const re = /\{"name":"([^"]*)","surname":"([^"]*)","point":(\d),"date":"([^"]*)","comment":"((?:[^"\\]|\\.)*)"/g;
  let m;
  while ((m = re.exec(first)) && reviews.length < 6) {
    const text = JSON.parse('"' + m[5] + '"').replace(/\s+/g, ' ').trim();
    if (text.length > 60) reviews.push([m[1].trim() + ' ' + (m[2].trim()[0] || '') + '.', +m[3], m[4], text.slice(0, 280)]);
  }
  const totalReviews = (first.match(/"reviewsTotalCount":(\d+)/) || [])[1];

  // 5) Sitenin beklediği sıkıştırılmış biçim
  const cats = [];
  const ci = n => { n = (n || '').trim(); let i = cats.indexOf(n); if (i < 0) { cats.push(n); i = cats.length - 1; } return i; };
  const rows = [...all.values()].map(x => [
    x.code,
    ((x.title || []).find(t => t.languageId === 1) || (x.title || [])[0] || { text: '' }).text.replace(/\s+/g, ' ').trim(),
    x.operationId, x.mainCategoryId, ci(x.categoryName),
    x.priceInfo?.amount || 0, x.m2Area || '', x.roomOptions || '', x.floor || '',
    (x.address || '').replace(/^İstanbul (Avrupa|Anadolu)\//, ''),
    x.employeeId, (x.images?.[0] || '').replace(PHOTO, ''), (x.images || []).length, x.isDiscounted ? 1 : 0
  ]);
  const teamRows = [...team.values()].map(o => [
    o.employeeId, (o.nameSurname || '').trim(), o.urlName, o.jobTitle, (o.registerDate || '').slice(0, 4),
    o.reviewsAvgPoint, o.reviewsCount, (o.image || '').replace(PHOTO, '')
  ]);

  return {
    source: 'live', updated: new Date().toISOString(),
    office: { ...OFFICE, reviewsTotal: totalReviews ? +totalReviews : OFFICE.reviewsTotal },
    cats,
    fields: ['code', 'title', 'op', 'main', 'cat', 'price', 'm2', 'rooms', 'floor', 'loc', 'emp', 'img', 'nimg', 'disc'],
    rows,
    teamFields: ['id', 'name', 'slug', 'title', 'since', 'rating', 'reviews', 'photo'],
    team: teamRows,
    reviews
  };
}

export default async () => {
  try {
    const data = await fetchAll();
    return new Response(JSON.stringify(data), {
      headers: {
        'Content-Type': 'application/json; charset=utf-8',
        'Cache-Control': 'public, max-age=300',
        // Netlify CDN: 15 dk taze, 1 saat boyunca arka planda yenilenirken eski sürüm sunulur
        'Netlify-CDN-Cache-Control': 'public, durable, s-maxage=900, stale-while-revalidate=3600'
      }
    });
  } catch (e) {
    // Hata olursa site otomatik olarak data/listings.json yedeğini kullanır
    return new Response(JSON.stringify({ error: String(e.message || e) }), {
      status: 502, headers: { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' }
    });
  }
};

// Netlify bu fonksiyonu doğrudan /api/ilanlar adresinde yayınlar
export const config = { path: '/api/ilanlar' };
